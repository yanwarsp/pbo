package com.pboreg;

public class Minuman extends Warnet {

    public void biayaMinuman() {
        System.out.println(" Biaya Teh Botol            : " + (int) this.minum + " botol" +"       Rp." + this.minum * 3000);
    }
}
