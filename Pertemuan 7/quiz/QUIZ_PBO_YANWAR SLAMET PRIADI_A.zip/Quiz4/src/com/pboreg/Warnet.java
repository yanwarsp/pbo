package com.pboreg;

public class Warnet {

    double ngetik, internet, game, scan, printWarna, printBW, minum;

    public Warnet() {
        this.ngetik = this.internet = this.game = this.scan = this.printWarna = this.printBW = this.minum = 0;
    }

    public void setInput(double ngetik, double internet, double game, double scan, double printWarna, double printBW, double minum) {
        this.ngetik = ngetik;
        this.internet = internet;
        this.game = game;
        this.scan = scan;
        this.printWarna = printWarna;
        this.printBW = printBW;
        this.minum = minum;
    }


}


